import os, pickle, time, csv, json, datetime
import numpy as np

try:
    import serial
except ImportError:
    print("ERROR: pip install pyserial")
    raise SystemExit(1)

PORT          = 'COM5'
BAUD          = 115200
DATASET       = 'RML2016.10a_dict.pkl'
TEST_INDICES  = 'test_split_indices.pkl'
MEAN_PATH     = 'norm_mean.npy'
STD_PATH      = 'norm_std.npy'
SNRS          = list(range(-20, 19, 2))

os.chdir(os.path.dirname(os.path.abspath(__file__)))

FRAC_BITS = 10
SCALE = 1 << FRAC_BITS
INPUT_LEN = 128
INPUT_CH = 2

CLASS_NAMES = ['8PSK', 'AM-DSB', 'AM-SSB', 'BPSK', 'CPFSK',
               'GFSK', 'PAM4', 'QAM16', 'QAM64', 'QPSK', 'WBFM']
NUM_CLASSES = len(CLASS_NAMES)

def quantise_normalized(frame_f32, mean_pos, std_pos):
    iq = (frame_f32 - mean_pos[None, :]) / std_pos[None, :]
    iq_t = iq.T
    words = []
    for t in range(INPUT_LEN):
        for ch in range(INPUT_CH):
            v = float(iq_t[t, ch]) * SCALE
            v = max(-32768, min(32767, int(round(v))))
            words.append(v & 0xFFFF)
    return words

def stuff(raw: bytes) -> bytes:
    out = bytearray()
    for b in raw:
        if b == 0xAA:
            out += b'\xAB\x00'
        elif b == 0xAB:
            out += b'\xAB\x01'
        else:
            out.append(b)
    return bytes(out)

def build_frame(words):
    assert len(words) == 256
    raw = bytearray(512)
    for i, w in enumerate(words):
        raw[i*2] = (w >> 8) & 0xFF
        raw[i*2+1] = w & 0xFF
    return b'\xAA' + stuff(bytes(raw))

def run_frame(ser, words, timeout=5.0):
    trame = build_frame(words)
    ser.reset_input_buffer()
    t0 = time.time()
    ser.write(trame)
    ser.flush()
    ser.timeout = timeout
    resp = ser.read(2)
    ms = (time.time() - t0) * 1000
    if len(resp) < 2:
        return None, None, ms
    return resp[0], resp[1], ms

print(f'Loading {MEAN_PATH} / {STD_PATH} ...')
mean_pos = np.load(MEAN_PATH).astype(np.float32).flatten()
std_pos = np.load(STD_PATH).astype(np.float32).flatten()

print(f'Loading {DATASET} ...')
with open(DATASET, 'rb') as f:
    data = pickle.load(f, encoding='latin1')
mods = sorted(set(k[0] for k in data.keys()))
class_to_idx = {m: i for i, m in enumerate(mods)}
idx_to_class = {v: k for k, v in class_to_idx.items()}

print(f'Loading {TEST_INDICES} ...')
with open(TEST_INDICES, 'rb') as f:
    test_indices = pickle.load(f)
sizes = [len(v) for v in test_indices.values()]
print(f'  {len(test_indices)} bins, {sum(sizes)} test frames total '
      f'(min={min(sizes)} max={max(sizes)} mean={np.mean(sizes):.1f})')

print(f'Opening {PORT} @ {BAUD} baud ...')
ser = serial.Serial(PORT, BAUD, timeout=5.0)
time.sleep(0.5)
ser.reset_input_buffer()
ser.reset_output_buffer()
print('  OK\n')

confusion = np.zeros((NUM_CLASSES, NUM_CLASSES), dtype=np.int64)
per_snr_correct = {snr: 0 for snr in SNRS}
per_snr_total = {snr: 0 for snr in SNRS}
rows = []
rtt_list = []
correct = 0
total = 0
timeouts = 0
fid_errors = 0
expected_fid = 0
frame_num = 0

t_start = time.time()

for snr in SNRS:
    for mod in mods:
        key = (mod, snr)
        if key not in data or key not in test_indices:
            continue
        arr = data[key]
        exp = class_to_idx[mod]
        selected_idx = sorted(i for i in test_indices[key] if i < arr.shape[0])

        for i in selected_idx:
            frame_f = arr[i]
            words = quantise_normalized(frame_f, mean_pos, std_pos)
            fid_got, cls_got, ms = run_frame(ser, words)

            row = {'frame_num': frame_num, 'mod': mod, 'snr': snr,
                   'local_index': i, 'expected_class': exp,
                   'frame_id': fid_got, 'pred_class': cls_got,
                   'round_trip_ms': round(ms, 2), 'status': None}

            if cls_got is None:
                timeouts += 1
                row['status'] = 'TIMEOUT'
                print(f'[{frame_num:>5}] {mod:<8} {snr:>4}dB  TIMEOUT')
            else:
                fid_ok = (fid_got == (expected_fid & 0xFF))
                if not fid_ok:
                    fid_errors += 1
                    row['status'] = 'FID_MISMATCH'
                    print(f'[{frame_num:>5}] {mod:<8} {snr:>4}dB  '
                          f'FID MISMATCH (exp {expected_fid & 0xFF}, got {fid_got})')
                else:
                    ok = (cls_got == exp)
                    correct += ok
                    total += 1
                    rtt_list.append(ms)
                    confusion[exp, cls_got if 0 <= cls_got < NUM_CLASSES else 0] += 1
                    per_snr_total[snr] += 1
                    per_snr_correct[snr] += ok
                    row['status'] = 'PASS' if ok else 'FAIL'
                expected_fid = (expected_fid + 1) & 0xFF

            rows.append(row)
            frame_num += 1
            if frame_num % 500 == 0:
                elapsed = time.time() - t_start
                print(f'  ... {frame_num} frames done, '
                      f'{elapsed/60:.1f} min elapsed, '
                      f'running acc so far: {100*correct/max(total,1):.2f}%')
            time.sleep(0.05)

ser.close()

print(f'\n{"="*70}')
global_acc = 100 * correct / total if total else 0.0
print(f'  ACCURACY GLOBALE : {correct}/{total} = {global_acc:.2f}%')
print(f'  Timeouts          : {timeouts}')
print(f'  FID errors        : {fid_errors}')
if rtt_list:
    print(f'  Round-trip (ms)   : avg={np.mean(rtt_list):.1f}  '
          f'min={np.min(rtt_list):.1f}  max={np.max(rtt_list):.1f}')
print(f'{"="*70}')

print(f'\n{"Accuracy par SNR":-^40}')
print(f'{"SNR (dB)":>10}  {"Correct/Total":>14}  {"Acc (%)":>8}')
by_snr = {}
for snr in SNRS:
    t = per_snr_total[snr]
    c = per_snr_correct[snr]
    acc = 100 * c / t if t else 0.0
    by_snr[snr] = {'correct': c, 'total': t, 'acc': round(acc, 2)}
    print(f'{snr:>10}  {c:>6}/{t:<7}  {acc:>7.2f}')

ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')

csv_path = f'board_full_sweep_results_{ts}.csv'
with open(csv_path, 'w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=['frame_num', 'mod', 'snr',
                                            'local_index', 'expected_class',
                                            'frame_id', 'pred_class',
                                            'round_trip_ms', 'status'])
    writer.writeheader()
    writer.writerows(rows)
print(f'\n  CSV: {csv_path}')

json_path = f'board_full_sweep_summary_{ts}.json'
with open(json_path, 'w') as f:
    json.dump({
        'global_accuracy_pct': round(global_acc, 2),
        'correct': correct, 'total': total,
        'timeouts': timeouts, 'fid_errors': fid_errors,
        'round_trip_ms': {
            'avg': round(float(np.mean(rtt_list)), 2) if rtt_list else None,
            'min': round(float(np.min(rtt_list)), 2) if rtt_list else None,
            'max': round(float(np.max(rtt_list)), 2) if rtt_list else None,
        },
        'accuracy_by_snr': by_snr,
        'confusion_matrix': {'class_order': CLASS_NAMES,
                              'matrix': confusion.tolist()},
    }, f, indent=2)
print(f'  JSON: {json_path}')
print(f'\n  Total time: {(time.time()-t_start)/60:.1f} minutes')
