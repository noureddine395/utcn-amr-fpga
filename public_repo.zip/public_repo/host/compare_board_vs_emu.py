import os, glob, argparse, datetime
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))

def newest(pattern):
    files = glob.glob(os.path.join(HERE, pattern))
    if not files:
        raise SystemExit(f'No file matches {pattern} in {HERE}')
    return max(files, key=os.path.getmtime)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--board', default=None, help='board CSV (default: newest board_full_sweep_results_*.csv)')
    ap.add_argument('--emu', default=None, help='emulator CSV (default: newest emu_hsig_*.csv)')
    ap.add_argument('--variant', default='B2_term_floor_hard_rndoff')
    ap.add_argument('--allow-old', action='store_true',
                    help='compare even if the board CSV is older than the emulator CSV')
    args = ap.parse_args()

    board_path = args.board or newest('board_full_sweep_results_*.csv')
    emu_path = args.emu or newest('emu_hsig_*.csv')
    print(f'board CSV    : {os.path.basename(board_path)}')
    print(f'emulator CSV : {os.path.basename(emu_path)}')
    print(f'variant      : {args.variant}')
    if os.path.getmtime(board_path) < os.path.getmtime(emu_path) and not args.allow_old:
        raise SystemExit(
            '\nSTOP: the board CSV is OLDER than the emulator CSV, so it may have been produced with\n'
            'the OLD weights and the comparison would be meaningless. Run run_board_full_sweep.py on\n'
            'the new bitstream first (it creates a new board_full_sweep_results_<date>.csv),\n'
            'or pass --allow-old if you know both files belong to the new weights\n'
            '(e.g. --board <new board csv> --emu <emu csv> --allow-old).')

    bd = pd.read_csv(board_path)
    em = pd.read_csv(emu_path)
    col = args.variant + '_pred_idx'
    if col not in em.columns:
        raise SystemExit(f'Column {col} not in emulator CSV. Available: '
                         f'{[c for c in em.columns if c.endswith("_pred_idx")]}')

    keys = ['mod', 'snr', 'local_index']
    df = bd.merge(em[keys + ['true_class_idx', col]], on=keys, how='inner')
    print(f'board rows: {len(bd)}   emulator rows: {len(em)}   matched: {len(df)}')
    if len(df) != len(bd):
        print('  WARNING: not all board frames were found in the emulator CSV '
              '(was the emulator run with --limit?)')

    valid = df['status'].isin(['PASS', 'FAIL'])
    print(f'valid board frames: {int(valid.sum())}   '
          f'invalid (timeout / frame-id mismatch): {int((~valid).sum())}')
    if (~valid).any():
        print(df.loc[~valid, 'status'].value_counts().to_string())

    d = df[valid].copy()
    d['board'] = d['pred_class'].astype(int)
    d['emu'] = d[col].astype(int)
    d['true'] = d['true_class_idx'].astype(int)
    if not (d['expected_class'].astype(int) == d['true']).all():
        print('  WARNING: expected_class (board) != true_class_idx (emulator) on some frames')

    d['b_ok'] = d['board'] == d['true']
    d['e_ok'] = d['emu'] == d['true']
    d['agree'] = d['board'] == d['emu']
    hi = d['snr'] >= 0

    print('\n' + '=' * 66)
    print(f'{"":<22}{"acc % (all)":>14}{"acc % (>=0dB)":>16}')
    print(f'{"BOARD":<22}{100 * d.b_ok.mean():>14.2f}{100 * d.b_ok[hi].mean():>16.2f}')
    print(f'{"EMULATOR " + args.variant[:2]:<22}{100 * d.e_ok.mean():>14.2f}{100 * d.e_ok[hi].mean():>16.2f}')
    print(f'{"agreement board/emu":<22}{100 * d.agree.mean():>14.2f}{100 * d.agree[hi].mean():>16.2f}')
    print('=' * 66)
    print(f'frames: {len(d)}   identical predictions: {int(d.agree.sum())}   '
          f'different: {int((~d.agree).sum())}')

    tab = (d.groupby('snr')[['b_ok', 'e_ok', 'agree']].mean() * 100).round(2)
    tab.insert(0, 'n', d.groupby('snr').size())
    tab.columns = ['n', 'board_acc', 'emu_acc', 'agreement']
    print('\nPer SNR:')
    print(tab.to_string())

    classes = sorted(d['mod'].unique())
    ctab = (d.groupby('true')[['b_ok', 'e_ok', 'agree']].mean() * 100).round(2)
    ctab.insert(0, 'n', d.groupby('true').size())
    ctab.index = [classes[i] for i in ctab.index]
    ctab.columns = ['n', 'board_recall', 'emu_recall', 'agreement']
    print('\nPer class (true label):')
    print(ctab.to_string())

    dis = d[~d['agree']]
    print(f'\nDisagreements: {len(dis)} frames ({100 * len(dis) / len(d):.2f}%)')
    if len(dis):
        pairs = dis.groupby(['board', 'emu']).size().sort_values(ascending=False).head(10)
        print('Most frequent (board -> emulator):')
        for (b, e), n in pairs.items():
            print(f'  {classes[b]:<8} -> {classes[e]:<8} {n}')
        ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        out = os.path.join(HERE, f'board_vs_emu_disagreements_{ts}.csv')
        dis[keys + ['true', 'board', 'emu']].to_csv(out, index=False)
        print(f'wrote {out}')

    ag = 100 * d.agree.mean()
    print('\nVerdict:')
    if ag >= 99.0:
        print('  Board matches the emulator -> the new RTL does what the emulator models.')
    elif ag >= 90.0:
        print('  Close but not identical -> small arithmetic difference between RTL and emulator.')
        print('  Look at which SNR range / class pairs disagree (tables above).')
    else:
        print('  Board and emulator differ a lot -> the new RTL does NOT compute what the emulator models')
        print('  (or the wrong bitstream / weights were loaded). Check the bitstream and the RTL first.')

if __name__ == '__main__':
    main()
