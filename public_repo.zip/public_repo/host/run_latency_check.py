import os, pickle, time, csv, json, datetime
import numpy as np

try:
    import serial
except ImportError:
    print("ERROR: pip install pyserial")
    raise SystemExit(1)

PORT             = 'COM5'
BAUD             = 115200
DATASET          = 'RML2016.10a_dict.pkl'
TEST_INDICES     = 'test_split_indices.pkl'
MEAN_PATH        = 'norm_mean.npy'
STD_PATH         = 'norm_std.npy'
SNRS             = list(range(-20, 19, 2))
FRAMES_PER_SNR   = 25
COMPUTE_MS       = 76.34
REPLY_BYTES      = 2

os.chdir(os.path.dirname(os.path.abspath(__file__)))

FRAC_BITS = 10
SCALE = 1 << FRAC_BITS
INPUT_LEN = 128
INPUT_CH = 2

CLASS_NAMES = ['8PSK', 'AM-DSB', 'AM-SSB', 'BPSK', 'CPFSK',
               'GFSK', 'PAM4', 'QAM16', 'QAM64', 'QPSK', 'WBFM']

def quantise_normalized(frame_f32, mean_pos, std_pos):
    iq = (frame_f32 - mean_pos[None, :]) / std_pos[None, :]
    iq_t = iq.T
    words = []
    for t in range(INPUT_LEN):
        for ch in range(INPUT_CH):
            v = float(iq_t[t, ch]) * SCALE
            v = max(-32768, min(32767, int(round(v))))
            words.append(v & 0xFFFF)
    return words

def stuff(raw: bytes) -> bytes:
    out = bytearray()
    for b in raw:
        if b == 0xAA:
            out += b'\xAB\x00'
        elif b == 0xAB:
            out += b'\xAB\x01'
        else:
            out.append(b)
    return bytes(out)

def build_frame(words):
    assert len(words) == 256
    raw = bytearray(512)
    for i, w in enumerate(words):
        raw[i * 2] = (w >> 8) & 0xFF
        raw[i * 2 + 1] = w & 0xFF
    return b'\xAA' + stuff(bytes(raw))

def run_frame(ser, words, timeout=5.0):
    trame = build_frame(words)
    ser.reset_input_buffer()

    t0 = time.perf_counter()
    ser.write(trame)
    t_w = time.perf_counter()
    ser.flush()
    t_f = time.perf_counter()
    ser.timeout = timeout
    resp = ser.read(REPLY_BYTES)
    t_r = time.perf_counter()

    timings = {
        'write_ms':       (t_w - t0) * 1000,
        'flush_ms':       (t_f - t0) * 1000,
        'after_flush_ms': (t_r - t_f) * 1000,
        'round_trip_ms':  (t_r - t0) * 1000,
    }
    if len(resp) < REPLY_BYTES:
        return None, None, timings, len(trame)
    return resp[0], resp[1], timings, len(trame)

print(f'Loading {MEAN_PATH} / {STD_PATH} ...')
mean_pos = np.load(MEAN_PATH).astype(np.float32).flatten()
std_pos = np.load(STD_PATH).astype(np.float32).flatten()

print(f'Loading {DATASET} ...')
with open(DATASET, 'rb') as f:
    data = pickle.load(f, encoding='latin1')
mods = sorted(set(k[0] for k in data.keys()))
class_to_idx = {m: i for i, m in enumerate(mods)}

print(f'Loading {TEST_INDICES} ...')
with open(TEST_INDICES, 'rb') as f:
    test_indices = pickle.load(f)

rng = np.random.default_rng(0)
plan = []
for snr in SNRS:
    pool = []
    for mod in mods:
        key = (mod, snr)
        if key in data and key in test_indices:
            arr = data[key]
            idx = sorted(i for i in test_indices[key] if i < arr.shape[0])
            pool += [(mod, snr, i) for i in idx]
    rng.shuffle(pool)
    plan += pool[:FRAMES_PER_SNR]
print(f'  {len(plan)} frames planned')

print(f'Opening {PORT} @ {BAUD} baud ...')
ser = serial.Serial(PORT, BAUD, timeout=5.0)
time.sleep(0.5)
ser.reset_input_buffer()
ser.reset_output_buffer()
print('  OK\n')

rows = []
expected_fid = 0
timeouts = fid_errors = correct = total = 0

for n, (mod, snr, i) in enumerate(plan):
    words = quantise_normalized(data[(mod, snr)][i], mean_pos, std_pos)
    fid, cls, tm, nbytes = run_frame(ser, words)

    upload_ms = nbytes * 10.0 / BAUD * 1000.0
    floor_ms = upload_ms + COMPUTE_MS + REPLY_BYTES * 10.0 / BAUD * 1000.0

    status = 'PASS'
    if cls is None:
        status = 'TIMEOUT'
        timeouts += 1
    else:
        if fid != (expected_fid & 0xFF):
            status = 'FID_MISMATCH'
            fid_errors += 1
        else:
            total += 1
            correct += int(cls == class_to_idx[mod])
        expected_fid = (expected_fid + 1) & 0xFF

    rows.append({'n': n, 'mod': mod, 'snr': snr, 'local_index': i,
                 'bytes_sent': nbytes,
                 'upload_expected_ms': round(upload_ms, 2),
                 'floor_expected_ms': round(floor_ms, 2),
                 'write_ms': round(tm['write_ms'], 3),
                 'flush_ms': round(tm['flush_ms'], 3),
                 'after_flush_ms': round(tm['after_flush_ms'], 3),
                 'round_trip_ms': round(tm['round_trip_ms'], 3),
                 'status': status})
    if (n + 1) % 100 == 0:
        print(f'  ... {n + 1}/{len(plan)} frames')
    time.sleep(0.05)

ser.close()

rt = np.array([r['round_trip_ms'] for r in rows if r['status'] != 'TIMEOUT'])
af = np.array([r['after_flush_ms'] for r in rows if r['status'] != 'TIMEOUT'])
wr = np.array([r['write_ms'] for r in rows if r['status'] != 'TIMEOUT'])
fl = np.array([r['flush_ms'] for r in rows if r['status'] != 'TIMEOUT'])
floor = np.array([r['floor_expected_ms'] for r in rows if r['status'] != 'TIMEOUT'])

print('\n' + '=' * 70)
print(f'  Frames: {len(rows)}   timeouts: {timeouts}   FID errors: {fid_errors}')
print(f'  Accuracy on this subset: {correct}/{total}')
print(f'  Round-trip   (ms): min={rt.min():.1f}  median={np.median(rt):.1f}  max={rt.max():.1f}')
print(f'  write()      (ms): min={wr.min():.1f}  median={np.median(wr):.1f}  max={wr.max():.1f}')
print(f'  flush done   (ms): min={fl.min():.1f}  median={np.median(fl):.1f}  max={fl.max():.1f}')
print(f'  after_flush  (ms): min={af.min():.1f}  median={np.median(af):.1f}  max={af.max():.1f}')
print(f'  Physical floor (upload+compute+reply): ~{floor.mean():.1f} ms')
print(f'  Frames below the floor      : {(rt < floor).sum()} / {len(rt)}')
print(f'  Frames with after_flush < {COMPUTE_MS} ms: {(af < COMPUTE_MS).sum()} / {len(af)}')
print('=' * 70)

reply_ms = REPLY_BYTES * 10.0 / BAUD * 1000.0
upl = np.array([r['upload_expected_ms'] for r in rows if r['status'] != 'TIMEOUT'])
implied = rt - upl - reply_ms
early = fl < 0.5 * upl
print(f'  Implied compute (round_trip - upload - reply): min={implied.min():.1f}  '
      f'median={np.median(implied):.1f} ms  (cycle count: {COMPUTE_MS} ms)')
print(f'  Frames where flush() returned early: {early.sum()} / {len(fl)}'
      + (f'   after_flush min there = {af[early].min():.1f} ms' if early.any() else ''))
print(f'  Frames delayed > 10 ms above the median: {(rt > np.median(rt) + 10).sum()} / {len(rt)}')

print('\nHOW TO READ THIS')
if implied.min() >= COMPUTE_MS:
    print(f'  The implied compute time is never below {COMPUTE_MS} ms.')
    print('  -> The board is consistent with the 76.34 ms cycle count.')
    print('     Frames far above the median are host/USB delays (flush() blocking).')
else:
    print(f'  The implied compute time is sometimes below {COMPUTE_MS} ms.')
    print('  -> The board answered faster than the cycle count predicts.')
    print('     Check before submitting: (1) the clock actually used on the board,')
    print('     (2) whether inference starts before the last UART bytes arrive,')
    print('     (3) the real baud rate of the USB-UART bridge.')

ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
csv_path = f'latency_check_{ts}.csv'
with open(csv_path, 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)
print(f'\n  CSV: {csv_path}')

json_path = f'latency_check_summary_{ts}.json'
with open(json_path, 'w') as f:
    json.dump({
        'frames': len(rows), 'timeouts': timeouts, 'fid_errors': fid_errors,
        'round_trip_ms': {'min': float(rt.min()), 'median': float(np.median(rt)), 'max': float(rt.max())},
        'after_flush_ms': {'min': float(af.min()), 'median': float(np.median(af)), 'max': float(af.max())},
        'floor_expected_ms': float(floor.mean()),
        'below_floor': int((rt < floor).sum()),
        'implied_compute_min_ms': float(implied.min()),
        'delayed_over_10ms': int((rt > np.median(rt) + 10).sum()),
    }, f, indent=2)
print(f'  JSON: {json_path}')
