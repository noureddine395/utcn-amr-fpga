import os, sys, time, pickle, csv, argparse, datetime
import numpy as np

try:
    import serial
except ImportError:
    sys.exit('ERROR: pip install pyserial')

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)

FRAC_BITS = 10
SCALE = 1 << FRAC_BITS
INPUT_LEN = 128
INPUT_CH = 2
FIELDS = ['frame_num', 'mod', 'snr', 'local_index', 'expected_class',
          'frame_id', 'pred_class', 'round_trip_ms', 'status']

def quantise_normalized(frame_f32, mean_pos, std_pos):
    iq = (frame_f32 - mean_pos[None, :]) / std_pos[None, :]
    iq_t = iq.T
    words = []
    for t in range(INPUT_LEN):
        for ch in range(INPUT_CH):
            v = float(iq_t[t, ch]) * SCALE
            v = max(-32768, min(32767, int(round(v))))
            words.append(v & 0xFFFF)
    return words

def stuff(raw: bytes) -> bytes:
    out = bytearray()
    for b in raw:
        if b == 0xAA:
            out += b'\xAB\x00'
        elif b == 0xAB:
            out += b'\xAB\x01'
        else:
            out.append(b)
    return bytes(out)

def build_frame(words):
    assert len(words) == 256
    raw = bytearray(512)
    for i, w in enumerate(words):
        raw[i * 2] = (w >> 8) & 0xFF
        raw[i * 2 + 1] = w & 0xFF
    return b'\xAA' + stuff(bytes(raw))

def run_frame(ser, words, timeout=5.0):
    trame = build_frame(words)
    ser.reset_input_buffer()
    t0 = time.time()
    ser.write(trame)
    ser.flush()
    ser.timeout = timeout
    resp = ser.read(2)
    ms = (time.time() - t0) * 1000
    if len(resp) < 2:
        return None, None, ms
    return resp[0], resp[1], ms

def save_csv(path, rows):
    with open(path, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--port', default='COM5')
    ap.add_argument('--baud', type=int, default=115200)
    ap.add_argument('--limit', type=int, default=1100,
                    help='number of held-out frames to test (0 = all 22,000)')
    ap.add_argument('--dataset', default='RML2016.10a_dict.pkl')
    ap.add_argument('--test-indices', default='test_split_indices.pkl')
    ap.add_argument('--mean-path', default='norm_mean.npy')
    ap.add_argument('--std-path', default='norm_std.npy')
    args = ap.parse_args()

    mean_pos = np.load(args.mean_path).astype(np.float32).flatten()
    std_pos = np.load(args.std_path).astype(np.float32).flatten()
    with open(args.dataset, 'rb') as f:
        data = pickle.load(f, encoding='latin1')
    with open(args.test_indices, 'rb') as f:
        tidx = pickle.load(f)

    mods = sorted({k[0] for k in data})
    snrs = sorted({k[1] for k in data})
    class_to_idx = {m: i for i, m in enumerate(mods)}

    frames = []
    for snr in snrs:
        for mod in mods:
            key = (mod, snr)
            if key not in tidx:
                continue
            arr = data[key]
            for i in sorted(j for j in tidx[key] if j < arr.shape[0]):
                frames.append((mod, snr, i))
    print(f'held-out frames available: {len(frames)}')

    if args.limit and args.limit < len(frames):
        rng = np.random.default_rng(0)
        sel = np.sort(rng.choice(len(frames), args.limit, replace=False))
        frames = [frames[i] for i in sel]
    print(f'frames to test: {len(frames)}')

    print(f'Opening {args.port} @ {args.baud} ...')
    ser = serial.Serial(args.port, args.baud, timeout=5.0)
    time.sleep(0.5)
    ser.reset_input_buffer()
    ser.reset_output_buffer()

    ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    csv_path = os.path.join(HERE, f'board_full_sweep_results_quick{len(frames)}_{ts}.csv')

    rows = []
    expected_fid = None
    correct = total = timeouts = fid_errors = 0
    snr_ok, snr_n = {}, {}
    t_start = time.time()

    try:
        for n, (mod, snr, i) in enumerate(frames):
            words = quantise_normalized(data[(mod, snr)][i], mean_pos, std_pos)
            fid_got, cls_got, ms = run_frame(ser, words)
            exp = class_to_idx[mod]
            row = {'frame_num': n, 'mod': mod, 'snr': snr, 'local_index': i,
                   'expected_class': exp, 'frame_id': fid_got,
                   'pred_class': cls_got, 'round_trip_ms': round(ms, 2), 'status': None}

            if cls_got is None:
                timeouts += 1
                row['status'] = 'TIMEOUT'
                print(f'[{n:>5}] {mod:<8} {snr:>4} dB  TIMEOUT')
            else:
                if expected_fid is None:
                    expected_fid = fid_got
                if fid_got != expected_fid:
                    fid_errors += 1
                    row['status'] = 'FID_MISMATCH'
                    print(f'[{n:>5}] {mod:<8} {snr:>4} dB  FID MISMATCH (exp {expected_fid}, got {fid_got})')
                else:
                    ok = (cls_got == exp)
                    correct += ok
                    total += 1
                    snr_n[snr] = snr_n.get(snr, 0) + 1
                    snr_ok[snr] = snr_ok.get(snr, 0) + ok
                    row['status'] = 'PASS' if ok else 'FAIL'
                expected_fid = (fid_got + 1) & 0xFF
            rows.append(row)

            if (n + 1) % 100 == 0:
                save_csv(csv_path, rows)
                print(f'  ... {n + 1}/{len(frames)} frames, {(time.time() - t_start) / 60:.1f} min, '
                      f'running acc {100 * correct / max(total, 1):.2f}%')
            time.sleep(0.05)
    except KeyboardInterrupt:
        print('\nInterrupted -- saving what was collected so far.')
    finally:
        ser.close()
        save_csv(csv_path, rows)

    print('\n' + '=' * 60)
    print(f'ACCURACY: {correct}/{total} = {100 * correct / max(total, 1):.2f}%')
    print(f'Timeouts: {timeouts}   FID errors: {fid_errors}')
    print('=' * 60)
    print(f'{"SNR":>6} {"correct/n":>12} {"acc %":>8}')
    for s in sorted(snr_n):
        print(f'{s:>6} {snr_ok[s]:>6}/{snr_n[s]:<5} {100 * snr_ok[s] / snr_n[s]:>8.2f}')
    print(f'\nCSV: {csv_path}')
    print('Next: run compare_board_vs_emu.py (it picks the newest board CSV automatically).')

if __name__ == '__main__':
    main()
